JQVMap.prototype.getPinId = function (cc) {
  return this.getCountryId(cc) + '_pin';
};
